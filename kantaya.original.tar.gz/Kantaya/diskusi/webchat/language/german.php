<?
/** 
 * @author  Felix Kronlage <fkr@grummel.net> 
 * @version $Id: german.php,v 1.7 2000/09/18 15:28:59 fkr Exp $ 
 */

define ('MSG_001', 'Kein aktivierter Raum verf&uuml;gbar.');
define ('MSG_002', '[ auf geht\'s ! ]');
define ('MSG_003', 'Chat Room:');
define ('MSG_004', 'Username:');
define ('MSG_005', 'Passwort:');
define ('MSG_006', 'Passwort merken.');
define ('MSG_007', 'Kostenloser Zugang. JETZT!');
define ('MSG_008', 'Verbindungsprobleme ?');
define ('MSG_009', 'Zur&uuml;ck zur Liste mit den Chat-R&auml;umen');
define ('MSG_010', 'Du hast einen nicht verf&uuml;gbaren Raum angew&auml;hlt. Bitte neue Wahl treffen.');
define ('MSG_011', 'Du hast keinen Spitznamen eingegeben');
define ('MSG_012', 'Um diesen Raum betreten zu k&ouml;nnen muss ein Passwort eingegeben werden.');
define ('MSG_013', 'Username und/oder Passwort falsch');
define ('MSG_014', 'Dieser Name ist bereit vergeben.');
define ('MSG_015', 'Ein Fehler ist aufgetreten.');
define ('MSG_016', 'Zur&uuml;ch zur vorherigen Seite.');
define ('MSG_017', 'Hilfe');
define ('MSG_018', 'Befehl');
define ('MSG_019', 'Beschreibung');
define ('MSG_020', 'text'); 		#command for /me
define ('MSG_021', 'Eigenkommentar');	#description for /me
define ('MSG_022', 'Spitzname Text');	#command for /msg
define ('MSG_023', 'Private Nachricht an Spitzname schicken'); #description for /msg
define ('MSG_024', 'Liesmich');
define ('MSG_025', 'Lizenz');
define ('MSG_026', 'weiter..');
define ('MSG_027', 'Willkommen zum WebChat !');
define ('MSG_028', '<big>W</big>illkommen zum <big>W</big>eb<big>C</big>hat !');

/* defines added by fkr - start at 60 */

define ('MSG_061', 'den Raum verlassen und vorher \'text\' in den Chat schreiben');          #description for /quit

define ('MSG_100', 'WebChat Administration');
define ('MSG_101', '<big>W</big>eb<big>C</big>hat <big>A</big>dministration');
define ('MSG_102', 'Login');
define ('MSG_104', 'Chat Rooms Management');
define ('MSG_105', 'Neuer Raum');
define ('MSG_106', 'Normal');
define ('MSG_107', 'Privat');
define ('MSG_108', 'Veraendern');
define ('MSG_109', 'Loeschen');

define ('MSG_110', '<b>Error:</b> Cookies nicht aktiviert.');
define ('MSG_111', '<b>Error:</b> Username und/oder Passwort falsch.');
define ('MSG_112', '<b>Error:</b> Zugang nicht m&ouml;glich. Session ist abgelaufen.');
define ('MSG_113', '<b>Error:</b> Raum ist nicht L&ouml;schbar. Bitte erst die User evakuieren. :)');

define ('MSG_114', 'Verlassen');

define ('MSG_200', '<font color="#808080" size="-3">Private rooms sind in diese Version noch nicht eingebaut, also bitte nicht benutzen.</font>');
?>
