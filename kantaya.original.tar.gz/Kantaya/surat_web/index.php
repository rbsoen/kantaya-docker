<?php
include ('../lib/cek_sesi.inc');
?>
<html>
<head><title>Lemari - Folder</title></head>
<frameset rows="29%,*" frameborder="1" border="0" framespacing="1" SCROLLING="No" noresize>
<frame src="/lib/kepala.php" name="judul">
<frameset cols="100%,*" frameborder="0" border="0" framespacing="1">
  <frame src="/surat_web/frame_surat.php" name="content" noresize>
</frameset>
</frameset>
<body>
<b>Browser Anda harus mampu menampilkan FRAME !</b>
</body>
</html>
