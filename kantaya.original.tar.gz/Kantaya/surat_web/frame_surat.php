<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 5</title>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>

<frameset framespacing="1" border="1" cols="165,*" frameborder="1">
  <frame name="navigasi" target="main" scrolling="no" noresize src="navigasi_surat.php">
  <frame name="isi_surat" scrolling="auto" src="index1.php">
</frameset>

</html>
