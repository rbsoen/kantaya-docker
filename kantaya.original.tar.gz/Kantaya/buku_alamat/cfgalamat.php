<?php

$db_host = "localhost";  // Location of the database
$db_user = "root";  // Username for the access
$db_pass = "";  //  Password for the access
$db_name = "kantaya";  //  Name of the database

$host = "localhost";
$root = "root";
$database = "kantaya";
?>


