<?php
   include ('../lib/cek_sesi.inc');
?>

<html>
<head>
<title>Frame Atas Modul Forum</title>
</head>
<body alink=blue vlink=blue>
<img src="../gambar/earth.gif"  alt="" border=0>
<font color=#225F95><h1>Proyek</h1></font>



</body>
</html>
