<?php
$host = "localhost";
$root = "root";
$database = "kantaya";
$ttlperhalaman = 4;
?>
