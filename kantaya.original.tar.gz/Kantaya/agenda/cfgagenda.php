<?php
$arrtipe = array ("Pertemuan", "Rapat", "Dinas Luar", "Cuti", "Lainnya");
$awaljamkrj = "07:00";
$akhirjamkrj = "18:00";
?>
