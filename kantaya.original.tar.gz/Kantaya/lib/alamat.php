define(AMPER,"BPPT);
