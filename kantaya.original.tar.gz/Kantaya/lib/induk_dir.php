<?php
/*Untuk menge-set root direktori, dll
*/

//Sesuiakan dengan root direktori
$induk_dir="/home/www/";
?>
