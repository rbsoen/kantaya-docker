 
 var $nama_perusahaan = 'BPPT';
 var $alamat = '1'; 
 var $telepon = '1'; 
 var $fax = '1'; 
 var $email = '1'; 
 var $url = '1'; 
 var 