<?php
//Anda harus merubah sesuai dengan konfigurasi profil dari perusahaan anda
$perusahaan = "Badan Pengkajian dan Penerapan Teknologi";
$alamat = "BPPT, Gedung II, Lantai 21, Jalan MH. Thamrin 08 Jakpus 10340 ";
$telepon = "Telp. 021-3169829 ";
$faximil = " Fax. 021-3169811";
$email = "Email : kantaya@inn.bppt.go.id ";
$url = " Website : www.inn.bppt.go.id";
$lokasi_logo = "../gambar/logo_bppt.gif";
?>

