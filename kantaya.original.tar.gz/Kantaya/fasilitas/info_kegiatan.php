<html>
<head><title>Informasi Kegiatan</title></head>

<body face="verdana,arial,helvetica" bgcolor="#eeeeee">
<br>
<center>
<?php

echo" <h2> Agenda Kegiatan </h2><br>Informasi Kegiatan No. ".$pkeg;

?>
</center>

</body>

</html>
