<html>
<head><title>Kantaya - Forum </title></head>
<frameset rows="29%,*" frameborder="1" border="1" framespacing="1" SCROLLING="No" noresize>
<frame src="/lib/kepala.php" name="judul" >
<frameset cols="30%,*" frameborder="1" border="1" framespacing="1">
  <frame src="navigasi_ap.php" name="navigasi" noresize>
  <frame src="blank.htm" name="isi">
</frameset>
</frameset>

</html>
