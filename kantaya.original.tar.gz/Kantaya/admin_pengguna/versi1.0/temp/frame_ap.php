<frameset cols='300,*'>
<frame name='kiri' src='grup.php'>
<frame name='isi' src='blank.htm'>
</frameset>
<html>
<body>
Your browser doesn't support frame !
</body>
</html>
