<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Untitled</title>
<style>
  #link{color:#FFFFCC; text-decoration:none;font-family:Verdana, Arial, Helvetica, Sans-serif}
</style>
</head>
<body>
<div align="center">
  <table border="0" width="100%">
    <tr>
      <td colspan="2">
        <div align="center">
          <center>
          <table border="0" cellpadding="4" width="100%">
            <tr>
              <td width="25%"><b><img border="0" src="../gambar/logobppt.jpg" width="122" height="87">
        </b></td>
              <td width="75%"><b><font size="3" face="Verdana">PT. Teknik Inti
                Ekatama</font></b>
                <p><font size="2" face="Verdana">Jalan Sudirman Kav. 10 A,
                Telepon (021) 317-9876, Fax: (021) 137-9876<br>
                Email: <a href="mailto:kelik@budiana.com">cs@tie.com</a>, Situs
                Web: http://<a href="http://www.budiana.com" target="_blank">www.tie.com</a></font></td>
            </tr>
          </table>
          </center>
        </div>
  <center>
  <div align="center">
    <table border="0" cellpadding="4" width="100%">
      <tr>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Muka</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><b><font color="#FFFFFF" size="1" face="Verdana"><img border="0" src="red_arrow_rt.gif" width="7" height="11"></font><font size="1" face="Verdana" color="#FFFF00">Agenda</font></b></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b><a href="/fasilitas/fasilitas.php" target=noframe id="link">Fasilitas</a></b></font></td>
        <td width="11%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b><a href="/buku_alamat/index.htm" id="link">Buku
          Alamat</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Lemari</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Di
          mana</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Proyek</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b><a href="forum/index.php?jnskategori=P" target=noframe id="link">Forum</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Diskusi</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>URL-Link</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Surat</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font color="#FFFFFF" size="1" face="Verdana"><b>Admin</b></font></td>
        <td width="9%" bgcolor="#0033CC" align="center"><font
color="#FFFFFF" size="1" face="Verdana"><b><a
href="/logout.php" id="link" target="_parent">Keluar</a></b></font></td>
      </tr>
    </table>
  </div>
  </center>
  </td>
</tr>
</table>
</body>
</html>
