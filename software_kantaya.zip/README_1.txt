FILE : README_1.TXT

File in harus dibaca pertama kali sebelum menginstal aplikasi Kantaya.

Untuk mendapatkan informasi mengenai perangkat lunak ini dapat anda temui pada direktori "Dokumen " yang terdiri dari file :

1. INTALL.TXT
2. README.TXT
3. MANUAL  KANTAYA .DOC
4. REFERENSI MANUAL.DOC
5. GPL.TXT

Perhatian baca INTALL.TXT sebelum menginstal software Kantaya !
Dari file tersebut Anda dapat informasi yang penting untuk mengaplikasikan software ini pada sistem Anda. 

Kami berharap Anda dapat memanfaatkan software ini dalam meningkatkan sistem dan kinerja Anda.


Penyusun 

TEAM KANTAYA


